from filter_functions import filter_file_lines
from pprint import pprint

pprint(filter_file_lines('config_r1.txt', 'interface'))

