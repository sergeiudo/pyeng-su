print('Import connect.py')


def connect_ssh(ip):
    print('Connect SSH to {}'.format(ip))


def connect_telnet(ip):
    print('Connect Telnet to {}'.format(ip))
