print('Import parse/juniper.py')


def parse_with_re(command, regex):
    print('Parse command {} with regex {}'.format(command, regex))


def parse_with_textfsm(command, template):
    print('Parse command {} with texfsm {}'.format(command, template))
