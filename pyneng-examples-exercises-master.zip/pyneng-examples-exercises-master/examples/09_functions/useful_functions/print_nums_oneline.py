import time

for num in range(10):
    print(num, end=' ')
    time.sleep(1)
