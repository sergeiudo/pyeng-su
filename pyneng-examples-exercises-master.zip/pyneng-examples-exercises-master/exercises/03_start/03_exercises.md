# Задания

### Задание 3.1

Выполните установку IPython в виртуальном окружении или глобально в системе, если виртуальные окружения не используются.

После установки, по команде ipython должен открываться интерпретатор IPython (вывод может незначительно отличаться):
```
$ ipython
Python 3.6.3 (default, Oct  9 2017, 11:46:27)
Type 'copyright', 'credits' or 'license' for more information
IPython 6.2.1 -- An enhanced Interactive Python. Type '?' for help.

In [1]:
```

