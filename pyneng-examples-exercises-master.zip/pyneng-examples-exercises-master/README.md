# pyneng-examples-exercises

Задания и примеры из книги "Python для сетевых инженеров" для Python 3.6

В репозитории две ветки:

* [master](https://github.com/natenka/pyneng-examples-exercises/) - все примеры и задания для Python 3.6
* [python2.7](https://github.com/natenka/pyneng-examples-exercises/tree/python2.7) - все примеры и задания для Python 2.7

